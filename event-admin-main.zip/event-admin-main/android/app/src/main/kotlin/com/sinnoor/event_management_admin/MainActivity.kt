package com.sinnoor.event_management_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
